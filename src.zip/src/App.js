 // src/App.js

import React, { useState } from 'react';
import FlightBookingForm from './FlightBookingForm';  // Assuming it's in the same src directory
import FlightBookingTable from './FlightBookingTable';  // Assuming it's in the same src directory
import './Flight-Booking.css';  // Assuming the CSS is in the same src directory


const App = () => {
  const [passengers, setPassengers] = useState([]);
  const [selectedPassenger, setSelectedPassenger] = useState(null);

  const addPassenger = (newPassenger) => {
    setPassengers([...passengers, newPassenger]);
  };

  const deletePassenger = (phone) => {
    setPassengers(passengers.filter((passenger) => passenger.phone !== phone));
  };

  const selectPassenger = (passenger) => {
    setSelectedPassenger(passenger);
  };

  const updatePassenger = (updatedPassenger) => {
    setPassengers(passengers.map((passenger) =>
      passenger.phone === updatedPassenger.phone ? updatedPassenger : passenger
    ));
    setSelectedPassenger(null);
  };

  return (
    <div className="app-container">
      <FlightBookingForm addPassenger={addPassenger} updatePassenger={selectedPassenger ? updatePassenger : null} />
      <FlightBookingTable passengers={passengers} deletePassenger={deletePassenger} selectPassenger={selectPassenger} />
    </div>
  );
};

export default App;
