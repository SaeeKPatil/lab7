import React from 'react';
import './flight-booking.css';

function PassengerList({ passengers, onDelete }) {
  return (
    <div className="container">
      <table>
        <thead>
          <tr>
            <th>Passenger Name</th>
            <th>From</th>
            <th>To</th>
            <th>Departure</th>
            <th>Arrival</th>
            <th>Phone Number</th>
            <th>Email ID</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {passengers.map((passenger, index) => (
            <tr key={index}>
              <td>{passenger.name}</td>
              <td>{passenger.from}</td>
              <td>{passenger.to}</td>
              <td>{passenger.departureDate}</td>
              <td>{passenger.arrivalDate}</td>
              <td>{passenger.phoneNumber}</td>
              <td>{passenger.email}</td>
              <td>
                <button className="delete" onClick={() => onDelete(passenger.phoneNumber)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PassengerList;

