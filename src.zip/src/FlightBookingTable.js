// src/components/FlightBookingTable.js

import React from 'react';
import './Flight-Booking.css';

const FlightBookingTable = ({ passengers, deletePassenger, selectPassenger }) => {
  return (
    <div className="table-container">
      <h3>Passenger List</h3>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>From</th>
            <th>To</th>
            <th>Date</th>
            <th>Departure</th>
            <th>Arrival</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {passengers.length > 0 ? (
            passengers.map((passenger, index) => (
              <tr key={index}>
                <td>{passenger.name}</td>
                <td>{passenger.from}</td>
                <td>{passenger.to}</td>
                <td>{passenger.date}</td>
                <td>{passenger.departureDate}</td>
                <td>{passenger.arrivalDate}</td>
                <td>{passenger.phone}</td>
                <td>{passenger.email}</td>
                <td>
                  <button onClick={() => selectPassenger(passenger)}>Edit</button>
                  <button onClick={() => deletePassenger(passenger.phone)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="9">No passengers added yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FlightBookingTable;
