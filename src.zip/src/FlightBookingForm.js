// src/components/FlightBookingForm.js

import React, { useState } from 'react';
import './Flight-Booking.css';

const FlightBookingForm = ({ addPassenger, updatePassenger }) => {
  const [passenger, setPassenger] = useState({
    name: '',
    from: '',
    to: '',
    date: '',
    departureDate: '',
    arrivalDate: '',
    phone: '',
    email: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPassenger((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (passenger.phone) {
      if (updatePassenger) {
        updatePassenger(passenger);
      } else {
        addPassenger(passenger);
      }
      setPassenger({
        name: '',
        from: '',
        to: '',
        date: '',
        departureDate: '',
        arrivalDate: '',
        phone: '',
        email: '',
      });
    }
  };

  return (
    <div className="booking-container">
      <h2>Flight Booking Form</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Passenger Name" value={passenger.name} onChange={handleChange} required />
        <input type="text" name="from" placeholder="From" value={passenger.from} onChange={handleChange} required />
        <input type="text" name="to" placeholder="To" value={passenger.to} onChange={handleChange} required />
        <input type="date" name="date" value={passenger.date} onChange={handleChange} required />
        <input type="date" name="departureDate" value={passenger.departureDate} onChange={handleChange} required />
        <input type="date" name="arrivalDate" value={passenger.arrivalDate} onChange={handleChange} required />
        <input type="text" name="phone" placeholder="Phone Number" value={passenger.phone} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email ID" value={passenger.email} onChange={handleChange} required />
        <button type="submit">{updatePassenger ? 'Update' : 'Add'} Passenger</button>
      </form>
    </div>
  );
};

export default FlightBookingForm;

